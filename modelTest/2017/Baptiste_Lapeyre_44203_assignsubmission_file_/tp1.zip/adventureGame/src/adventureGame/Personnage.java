package adventureGame;

import adventureGame.comportement.ComportementArme;

public class Personnage {

	ComportementArme comportementarme;
	
	public void combattre(){
		comportementarme.UtiliserArme();
	}
	
	public void SetArme(ComportementArme c){
		comportementarme = c;
	}

	public Personnage(ComportementArme c) {
		comportementarme = c;
	}
}
