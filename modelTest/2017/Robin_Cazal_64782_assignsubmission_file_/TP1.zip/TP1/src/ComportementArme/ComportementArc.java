package ComportementArme;

import Comportement.ComportementArme;

public class ComportementArc implements ComportementArme {
 
	public void utiliserArme() {
		System.out.println("Je vais lui en tirer une dans le dos !");
	}
}
