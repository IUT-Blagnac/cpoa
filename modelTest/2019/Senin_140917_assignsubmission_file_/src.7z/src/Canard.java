/**
 * @author bruel
 *
 */
abstract public class Canard {
	
	protected ComportementCancan comportementCancan;
	protected ComportementVol comportementVol;

	public final void cancaner() {
		comportementCancan.cancaner();;
	}

	public void nager() {
		System.out.println("Je nage comme un Canard!");
	}

	public void voler() {
		comportementVol.voler();
	}

	abstract public void afficher();
	
}