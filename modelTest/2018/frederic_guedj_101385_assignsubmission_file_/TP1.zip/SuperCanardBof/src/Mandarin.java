
public class Mandarin extends Canard {
	
	public void afficher() {
		System.out.println("Je suis un mandarin");
	}
}
