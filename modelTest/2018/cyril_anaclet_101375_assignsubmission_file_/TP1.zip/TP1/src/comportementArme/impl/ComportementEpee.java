package comportementArme.impl;

import comportementArme.ComportementArme;

public class ComportementEpee implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Je me bat avec une epee!");

	}

}
