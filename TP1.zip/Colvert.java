/**
 * @author bruel
 *
 */
public class Colvert extends Canard {

	@Override
	public void afficher() {
		System.out.println("Je suis un Colvert");
	}

}