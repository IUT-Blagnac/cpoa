
public class NePasVoler implements ComportementVol {

	public void voler() {
		System.out.println("Je ne vole pas!");
	}
}
