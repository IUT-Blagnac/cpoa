
public class CanardMuet implements ComportementCancan {

	public void cancaner() {
		System.out.println("Je suis Muet !");
	}
}
