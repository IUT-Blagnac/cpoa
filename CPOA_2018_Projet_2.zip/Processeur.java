public class Processeur {

    public String nomCPU;

    public Processeur(String nomCPU) {
        this.nomCPU = nomCPU;
    }

    public void allumer(){
        System.out.println("CPU : Je m'allume");
    }
}
