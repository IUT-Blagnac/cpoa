
/*public class Bourreau extends Personnage {
	
	
	
}*/
