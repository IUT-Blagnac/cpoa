import java.util.Scanner;

import Comportements.ComportementArc;
import Comportements.ComportementArme;
import Comportements.ComportementEpee;
import Comportements.ComportementPoignard;

public class MainMenu {

	public static void main(String[] args) {
		
		Personnage monPerso=null;
		ComportementArme monArme=null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Choississez l'arme de votre personnage \n\n"
				+ "1.Poignard\n"
				+ "2.Arc\n"
				+ "3.Epee\n");
		int choix=sc.nextInt();
		
		switch(choix) {
		case 1:
			monArme= new ComportementPoignard();
			break;
		case 2:
			monArme= new ComportementArc();
			break;
		case 3:
			monArme= new ComportementEpee();
			break;

		default:break;
		
		}

		
		System.out.println("Choississez votre classe de personnage \n\n"
				+ "1.Roi\n"
				+ "2.Reine\n"
				+ "3.Chevalier\n"
				+ "4.Troll\n");
		int choix2=sc.nextInt();
		
		switch(choix2) {
		case 1:
			monPerso= new Roi(monArme);
			break;
		case 2:
			monPerso= new Reine(monArme);
			break;
		case 3:
			monPerso= new Chevalier(monArme);
			break;
		case 4:
			monPerso= new Troll(monArme);
			break;
		
		default:break;
		
		}
		monPerso.afficher();
		monPerso.combattre();
		monPerso.SetArme(new ComportementPoignard());
		System.out.println("J'ai changer mon arme pour un Poignard");
		monPerso.combattre();
	}

}
