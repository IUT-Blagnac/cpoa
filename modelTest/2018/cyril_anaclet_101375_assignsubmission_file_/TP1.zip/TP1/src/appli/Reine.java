package appli;

import comportementArme.ComportementArme;


public class Reine extends Personnage{
	
	public Reine(ComportementArme a) {
		super(a);
	}
	
	
}
