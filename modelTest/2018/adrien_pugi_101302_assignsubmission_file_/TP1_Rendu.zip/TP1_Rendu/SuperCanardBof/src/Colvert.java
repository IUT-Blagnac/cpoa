/**
 * @author bruel
 *
 */
public class Colvert extends Canard {
	public Colvert () {
		this.cV=new VolerAvecDesAiles();
		this.cC=new Cancan();
	}
	
	public void setMalade() {
		this.setMalade();
		this.cV=new NePasVoler();
	}
	
	@Override
	public void afficher() {
		System.out.println("Je suis un Colvert");
	}

}