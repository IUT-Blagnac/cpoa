package adventureGame;

import adventureGame.comportement.ComportementArme;

public class Troll extends Personnage {

	public Troll(ComportementArme c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void combattre() {
		super.combattre();
	}

	
}
