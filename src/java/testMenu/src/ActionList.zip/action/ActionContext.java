/**
 * 
 */
package action;

public interface ActionContext<E> {
	
	public E getContext();
	
}
