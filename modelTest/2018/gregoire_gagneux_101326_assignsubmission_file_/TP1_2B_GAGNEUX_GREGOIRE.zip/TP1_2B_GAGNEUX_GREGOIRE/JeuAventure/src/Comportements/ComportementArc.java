package Comportements;

public class ComportementArc implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Je combat avec un Arc!");
	}

}
