/**
 * @author bruel
 *
 */
abstract public class Canard {

	protected ComportementVol cV;
	protected ComportementCancan cC;
	
	public void cancaner() {
		this.cC.cancaner();
	}

	public void nager() {
		System.out.println("Je nage comme un Canard!");
	}

	public void voler() {
		this.cV.voler();
	}

	abstract public void afficher();
	
}