package adventureGame;

import adventureGame.comportement.ComportementArme;

public class Chevalier extends Personnage {

	public Chevalier(ComportementArme c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void combattre() {
		super.combattre();
	}

	
}
