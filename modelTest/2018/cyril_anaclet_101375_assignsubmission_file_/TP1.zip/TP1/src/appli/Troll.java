package appli;

import comportementArme.ComportementArme;


public class Troll extends Personnage {

		public Troll(ComportementArme a) {
			super(a);
		}
}
