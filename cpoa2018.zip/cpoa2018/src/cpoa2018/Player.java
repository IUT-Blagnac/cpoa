package cpoa2018;

public class Player
{
  int card;
  double money;
}