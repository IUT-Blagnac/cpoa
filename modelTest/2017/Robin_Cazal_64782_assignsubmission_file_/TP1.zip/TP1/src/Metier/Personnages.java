package Metier;

import Comportement.ComportementArme;

public abstract class Personnages {

	protected ComportementArme arme ;



	public Personnages (ComportementArme parme) {

		this.arme=parme ;
	}

	public final void Combattre() {
		this.arme.utiliserArme();
	}

	public void setArme(ComportementArme a) {

		this.arme=a;

	}

}
