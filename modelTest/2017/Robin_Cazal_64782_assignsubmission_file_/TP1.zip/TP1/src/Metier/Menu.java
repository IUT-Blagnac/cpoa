package Metier;

import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {

		

		System.out.println("Quel personnage veux-tu ?");
		System.out.println("1- Le roi");
		System.out.println("2- La reine");
		System.out.println("3- Le chevalier");
		System.out.println("4- Le troll");

		Scanner saisie = new Scanner(System.in);
		int classe  = saisie.nextInt();
		Personnages perso;

		switch(classe) {

		case 1 :
			perso =new Roi();
			System.out.println("Maitre du jeu : Huuum, le Roi ,tres bon choix!");
			System.out.println("Roi : Je suis ton Roi donc soumet toi !");
			break ;
		case 2 :
			perso =new Reine();
			System.out.println("Maitre du jeu : Ah, le Reine , Que le sort vous sois favorable!");
			System.out.println("Reine : Je suis Belle en plus d'etre Reine, jaloux ?");
			break ;
		case 3 :
			perso =new Chevalier();
			System.out.println("Sir Rodrigue : Sir Rodrigue a votre service, je suis un chevalier de haut rang !");
			System.out.println("Sir Rodrigue : Par l'honner des chevalier , EN GARDE !!!");
			break ;
		case 4 :
			perso =new Troll();
			System.out.println("Troll : Huun !!!, Manger Humain! Moi Troll !");
			System.out.println("Troll : combat HUUUUUUUUN !");
			break ;
		default :
			System.out.println("Maitre du jeu : Pardon mon seigneur je n'ai pas compris, par manque de temps nous vous donnont la classe par defaut sois chevalier");
			perso =new Chevalier();
			System.out.println("Sir Rodrigue : Sir Rodrigue a votre service, je suis un chevalier de haut rang !");
			System.out.println("Sir Rodrigue : Par l'honner des chevalier , EN GARDE !!!");
			break ;	

		}
		
		
		
		
	}
}


