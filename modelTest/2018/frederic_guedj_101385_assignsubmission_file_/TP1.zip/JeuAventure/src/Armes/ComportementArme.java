package Armes;
public interface ComportementArme {

	public void utiliserArme();

}
