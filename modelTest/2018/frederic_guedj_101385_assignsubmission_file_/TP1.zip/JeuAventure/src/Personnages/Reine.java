package Personnages;

import Armes.ComportementArme;

public class Reine extends Personnage {

	public Reine(ComportementArme c) {
		super(c);
	}
}
