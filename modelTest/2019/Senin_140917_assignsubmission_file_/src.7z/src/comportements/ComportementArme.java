package comportements;

public interface ComportementArme {

	public static void utiliserArme() {
		
	}
}
