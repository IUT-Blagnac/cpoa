public class Alimentation {

    public String puissance;

    public Alimentation(String puissance) {
        this.puissance = puissance;
    }
    

}
