package Comportement;

public interface ComportementArme {
	public default void utiliserArme() {
		
	}

}
