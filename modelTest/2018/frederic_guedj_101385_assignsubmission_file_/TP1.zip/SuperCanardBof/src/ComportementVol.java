
public interface ComportementVol {
	
	public void voler();

}
