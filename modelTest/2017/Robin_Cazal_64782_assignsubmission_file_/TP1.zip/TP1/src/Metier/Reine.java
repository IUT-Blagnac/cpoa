package Metier;


import ComportementArme.ComportementPoignard;

public class Reine extends Personnages{
	
	public Reine () {
		super(new ComportementPoignard());
		
		
	}

}
