package comportementArme.impl;

import comportementArme.ComportementArme;

public class ComportementPoignard implements ComportementArme{

	@Override
	public void utiliserArme() {
		System.out.println("Je me bat avec un poignard!");
		
	}

}
