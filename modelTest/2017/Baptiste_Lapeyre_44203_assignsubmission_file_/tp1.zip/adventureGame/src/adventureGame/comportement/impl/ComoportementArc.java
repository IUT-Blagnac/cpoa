package adventureGame.comportement.impl;

import adventureGame.comportement.ComportementArme;

public class ComoportementArc implements ComportementArme {

	@Override
	public void UtiliserArme() {
		System.out.println("Arc");
		
	}

}
