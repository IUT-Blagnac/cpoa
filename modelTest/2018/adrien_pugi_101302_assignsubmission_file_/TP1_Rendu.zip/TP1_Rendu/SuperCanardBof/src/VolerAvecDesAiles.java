
public class VolerAvecDesAiles implements ComportementVol {

	public void voler() {
		System.out.println("Je vole avec des ailes!");
	}
}
