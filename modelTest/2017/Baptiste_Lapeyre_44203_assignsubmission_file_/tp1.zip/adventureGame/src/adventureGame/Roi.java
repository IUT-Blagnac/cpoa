package adventureGame;

import adventureGame.comportement.ComportementArme;

public class Roi extends Personnage {

	public Roi(ComportementArme c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void combattre() {
		super.combattre();
	}

	
}
