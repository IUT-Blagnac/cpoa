package appli;
import comportementArme.*;

public abstract class Personnage {
	protected ComportementArme arme;

	Personnage(ComportementArme a)  {
		setArme(a);
	}
	
	public final void combattre() {
		this.arme.utiliserArme();
	}
	
	 final void setArme ( ComportementArme a) {
		this.arme = a;
	}
	
	 
}
