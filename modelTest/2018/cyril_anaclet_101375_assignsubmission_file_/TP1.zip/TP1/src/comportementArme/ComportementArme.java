package comportementArme;

public interface ComportementArme {
	public void utiliserArme();
}
