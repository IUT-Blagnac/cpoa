
public class Cancan implements ComportementCancan {
	
	@Override
	public void cancaner() {
		System.out.println("Je cancane!");
	}

}
