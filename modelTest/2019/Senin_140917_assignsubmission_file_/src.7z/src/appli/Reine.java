package appli;

public class Reine extends Personnage{

}
