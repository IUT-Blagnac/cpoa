package Personnages;

import Armes.ComportementArme;

public class Troll extends Personnage {

	public Troll(ComportementArme c) {
		super(c);
	}
}
