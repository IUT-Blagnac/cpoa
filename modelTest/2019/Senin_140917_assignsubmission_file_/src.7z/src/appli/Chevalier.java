package appli;

public class Chevalier extends Personnage{

}
