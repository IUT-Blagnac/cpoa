import Comportements.ComportementArme;

public class Chevalier extends Personnage {

	public Chevalier(ComportementArme a) {
		super(a);
		// TODO Auto-generated constructor stub
	}
	
	public void afficher() {
		System.out.println("Je suis un Chevalier(Deus Vult)!");
	}
	
}
