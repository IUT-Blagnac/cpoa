package ComportementArme;

import Comportement.ComportementArme;

public class ComportementPoignard  implements ComportementArme {
	
	public void utiliserArme() {
		System.out.println("Coup de schlass dans ta gueule");
	}

}
