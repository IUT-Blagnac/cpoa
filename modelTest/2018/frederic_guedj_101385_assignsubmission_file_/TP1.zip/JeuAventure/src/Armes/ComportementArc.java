package Armes;

public class ComportementArc implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Votre personnage envoie une fleche !");
	}

}
