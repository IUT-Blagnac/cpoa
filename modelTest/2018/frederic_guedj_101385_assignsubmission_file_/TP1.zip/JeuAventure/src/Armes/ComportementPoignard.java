package Armes;

public class ComportementPoignard implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Votre personnage donne un coup de poignard !");
	}

}
