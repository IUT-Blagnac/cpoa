package appli;

public class Roi extends Personnage{

}
