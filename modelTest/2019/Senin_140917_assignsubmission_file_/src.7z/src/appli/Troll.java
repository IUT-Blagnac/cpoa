package appli;

public class Troll extends Personnage{
	

}
