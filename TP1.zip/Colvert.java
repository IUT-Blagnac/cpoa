public class Colvert extends Canard {

	public void afficher() {
		System.out.println("Je suis un Colvert");
	}

}