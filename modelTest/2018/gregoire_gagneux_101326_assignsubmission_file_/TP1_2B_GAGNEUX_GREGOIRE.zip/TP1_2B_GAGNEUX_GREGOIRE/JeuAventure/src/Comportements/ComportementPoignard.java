package Comportements;

public class ComportementPoignard implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Je combat avec un Poignard!");
	}

}
