package adventureGame.comportement.impl;

import adventureGame.comportement.ComportementArme;

public class ComportementPoignard implements ComportementArme {

	@Override
	public void UtiliserArme() {
		System.out.println("poignard");
		
	}

}
