/**
 * @author bruel
 *
 */
abstract public class Canard {
	
	/**
	 * @overrideAssoc
	 */
	protected ComportementVol comportementVol;
	
	/**
	 * @overrideAssoc
	 */
	protected ComportementCancan comportementCancan;
	
	public final void cancaner() {
		comportementCancan.cancaner();
		
	}

	public void nager() {
		System.out.println("Je nage comme un Canard!");	
	}

	public final void voler() {
		comportementVol.voler();
		
	}
	
	abstract public void afficher();

	
}