import Comportements.ComportementArme;

public class Roi extends Personnage {

	public Roi(ComportementArme a) {
		super(a);
		// TODO Auto-generated constructor stub
	}
	
	public void afficher() {
		System.out.println("Je suis un Roi!");
	}
	

}
