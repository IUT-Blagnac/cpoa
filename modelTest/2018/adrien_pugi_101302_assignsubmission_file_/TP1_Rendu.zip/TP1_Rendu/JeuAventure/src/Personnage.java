import Comportements.ComportementArme;

abstract public class Personnage {

	protected ComportementArme cA;
	
	public Personnage(ComportementArme a) {
		SetArme(a);
		
	}
	
	public void combattre() {
		cA.utiliserArme();
	}

	public void SetArme(ComportementArme a) {
		cA=a;
	}
	public void afficher() {
	}

}