package comportements;

public class ComportementPoignard {

}
