/**
 * @author bruel
 *
 */

public class CanardEnPlastique extends Canard {

	public CanardEnPlastique() {
		// TODO Auto-generated constructor stub
		comportementCancan = new Cancan();
		comportementVol = new NePasVoler();
	}
	
	@Override
	public void afficher() {
		System.out.println("Je suis un CanardEnPlastique!");
	}
	
}
