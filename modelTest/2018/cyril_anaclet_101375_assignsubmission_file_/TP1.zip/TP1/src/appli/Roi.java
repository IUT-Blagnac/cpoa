package appli;

import comportementArme.ComportementArme;

public class Roi extends Personnage {
	
	public Roi(ComportementArme a) {
		super(a);
	}
}
