
public class Coincoin implements ComportementCancan{

	@Override
	public void cancaner() {
		// TODO Auto-generated method stub
		
	}

}
