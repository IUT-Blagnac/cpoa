package comportementArme.impl;

import comportementArme.ComportementArme;

public class ComportementArc implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Je me bat avec un arc!");

	}

}
