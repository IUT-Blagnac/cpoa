public class Main {
    public static void main(String[] args) {

        DELLX4000 MonOrdi = new DELLX4000();
        MonOrdi.AllumerPC();

    }
}
