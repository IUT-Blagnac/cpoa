package Armes;

public class ComportementEpee implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Votre personnage donne un coup d'epee !");
	}

}
