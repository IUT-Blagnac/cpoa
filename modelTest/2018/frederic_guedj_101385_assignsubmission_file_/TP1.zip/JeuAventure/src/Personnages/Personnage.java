package Personnages;

import Armes.ComportementArme;

public abstract class Personnage {
	
	protected ComportementArme arme;

	public Personnage (ComportementArme c) {
		this.arme = c;
	}
	
	public void combattre() {
		this.arme.utiliserArme();
	}
	
	public void setArme(ComportementArme a) {
		this.arme = a;
	}
}
