
package adventureGame.comportement.impl;

import adventureGame.comportement.ComportementArme;

public class ComoportementEpee implements ComportementArme {

	@Override
	public void UtiliserArme() {
		System.out.println("Epee");
		
	}

}
