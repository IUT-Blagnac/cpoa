package appli;

import comportements.ComportementArme;

public abstract class Personnage {
	
	protected ComportementArme = 

}
