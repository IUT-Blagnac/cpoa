public class CanardMuet implements ComportementCancan {
	
	@Override
	public void cancaner() {
		System.out.println("Ne cancane pas");
	}

}
