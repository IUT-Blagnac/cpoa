package ComportementArme;

import Comportement.ComportementArme;

public class ComportementEpee  implements ComportementArme  {
	
	public void utiliserArme() {
		System.out.println("Il va tater de mon epee !");
	}

}
