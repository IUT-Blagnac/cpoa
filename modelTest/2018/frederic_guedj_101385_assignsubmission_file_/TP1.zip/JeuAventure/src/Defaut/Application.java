package Defaut;
import Personnages.Chevalier;
import Personnages.Reine;
import Personnages.Roi;
import Personnages.Troll;
import Personnages.Personnage;

import Armes.ComportementArc;
import Armes.ComportementEpee;
import Armes.ComportementPoignard;

import java.util.Scanner;

public class Application {

	public static void main(String[] args) {
		
		Personnage p = null;
		
		// CASE 1: CHOIX PERSONNAGE
		System.out.println("Selection du personnage:");
		System.out.println("1.Chevalier \n2.Reine\n3.Roi\n4.Troll\n");
		System.out.println("Entrez le numero du personnage que vous souhaitez creer: ");
		
		Scanner sc = new Scanner(System.in);
		int choixPersonnage = sc.nextInt();
		
		switch(choixPersonnage) {
		
		case 1:
			p = new Chevalier(new ComportementPoignard());
			p.combattre();
			break;
		
		case 2:
			p = new Reine(new ComportementArc());
			p.combattre();
			break;
			
		case 3:
			p = new Roi(new ComportementEpee());
			p.combattre();
			break;
			
		case 4:
			p = new Troll(new ComportementPoignard());
			p.combattre();
			break;
			
		default:
			System.out.println("Erreur !");
			break;
		}
		
		//CASE 2: CHOIX ARME
		System.out.println("\nSelection de l'arme:");
		System.out.println("1.Arc \n2.Epee\n3.Poignard\n4.Aucune nouvelle arme\n");
		System.out.println("Entrez le numero de l'arme que vous souhaitez attribuer a votre personnage: ");
		
		int choixArme = sc.nextInt();
		
		switch(choixArme) {
		
		case 1:
			p.setArme(new ComportementArc());
			p.combattre();
			break;
		
		case 2:
			p.setArme(new ComportementEpee());
			p.combattre();
			break;
			
		case 3:
			p.setArme(new ComportementPoignard());
			p.combattre();
			break;
			
		case 4:
			p.combattre();
			break;
			
		default:
			System.out.println("Erreur !");
			break;
		}
	}

}
