public class CarteGraphique {

    public String nomCG;

    public CarteGraphique(String nomCG) {
        this.nomCG = nomCG;
    }

    public void allumer() {
        System.out.println("GPU : Je m'allume");
    }
}
