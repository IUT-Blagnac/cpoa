package Comportements;

public interface ComportementArme {
	
	public void utiliserArme();
	
}
