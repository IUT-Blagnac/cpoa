public class Leurre extends Canard {
	
	public void afficher() {
		System.out.println("Je suis un leurre");
	};

}
