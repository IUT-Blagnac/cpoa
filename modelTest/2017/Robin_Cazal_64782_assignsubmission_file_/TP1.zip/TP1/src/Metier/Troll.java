package Metier;

import ComportementArme.ComportementEpee;

public class Troll extends Personnages{
	
	public Troll () {
		super(new ComportementEpee());
		
		
	}

}
