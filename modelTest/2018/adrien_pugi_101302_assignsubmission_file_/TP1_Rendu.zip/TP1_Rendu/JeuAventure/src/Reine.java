import Comportements.ComportementArme;

public class Reine extends Personnage{

	public Reine(ComportementArme a) {
		super(a);
		// TODO Auto-generated constructor stub
	}
	
	public void afficher() {
		System.out.println("Je suis une Reine !");
	}
	
}