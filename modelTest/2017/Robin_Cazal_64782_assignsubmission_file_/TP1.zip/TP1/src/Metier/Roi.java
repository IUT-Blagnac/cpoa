package Metier;

import ComportementArme.ComportementArc;

public class Roi  extends Personnages {
	
	public Roi () {
		super(new ComportementArc());
		
		
		
	}

}
