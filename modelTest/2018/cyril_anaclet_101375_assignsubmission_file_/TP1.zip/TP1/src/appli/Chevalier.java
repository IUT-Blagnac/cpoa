package appli;

import comportementArme.ComportementArme;


public class Chevalier extends Personnage {

	public Chevalier(ComportementArme a) {
		super(a);
	}
	
}
