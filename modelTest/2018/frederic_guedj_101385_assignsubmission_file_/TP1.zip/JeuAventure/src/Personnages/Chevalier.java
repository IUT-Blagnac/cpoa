package Personnages;

import Armes.ComportementArme;

public class Chevalier extends Personnage {

	public Chevalier(ComportementArme c) {
		super(c);
	}
}
