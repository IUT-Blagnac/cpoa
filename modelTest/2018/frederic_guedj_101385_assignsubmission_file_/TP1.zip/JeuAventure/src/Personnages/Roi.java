package Personnages;

import Armes.ComportementArme;

public class Roi extends Personnage {

	public Roi(ComportementArme c) {
		super(c);
	}
}
