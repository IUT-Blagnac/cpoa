package Metier;

import ComportementArme.ComportementEpee;

public class Chevalier extends Personnages {
	
	public Chevalier () {
		super(new ComportementEpee());
		
		
	}

}
