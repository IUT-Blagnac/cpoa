/**
 * @author bruel
 *
 */

public class CanardEnPlastique extends Canard {
	
	public CanardEnPlastique () {
		this.cV=new NePasVoler();
		this.cC=new Cancan();
	}
	
	@Override
	public void afficher() {
		System.out.println("Je suis un CanardEnPlastique!");
	}

}
