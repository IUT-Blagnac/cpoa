package adventureGame.comportement;

public interface ComportementArme {
	public void UtiliserArme();
}
