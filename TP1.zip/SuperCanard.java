public class SuperCanard {

	public static void main(String[] args) {
		Canard c1 = new Colvert();
		c1.cancaner();
		c1.nager();
		c1.afficher();
		c1.voler();
	}

}
