package adventureGame;

import java.util.Scanner;

import javax.annotation.processing.SupportedSourceVersion;

import adventureGame.comportement.ComportementArme;
import adventureGame.comportement.impl.ComoportementArc;
import adventureGame.comportement.impl.ComoportementEpee;
import adventureGame.comportement.impl.ComportementPoignard;

public class main {
	
	

	public static void main(String[] args) {

		Scanner cl = new Scanner(System.in);
		Personnage p = null;
		boolean valid = false;
		
		while (!valid) {
			System.out.println("selectioner perso");
			
			String perso = cl.nextLine();
			perso = perso.toLowerCase();
			
			
			switch (perso) {
			case "reine":
				p = new Reine(selectArme());
				valid = true;
				break;
			case "roi":
				p = new Roi(selectArme());
				valid = true;
				break;
			case "troll":
				p = new Troll(selectArme());
				valid = true;
				break;
			case "chevalier":
				p = new Chevalier(selectArme());
				valid = true;
				break;
			default:
				
				break;
			}
		}
		p.comportementarme.UtiliserArme();
		
		p.SetArme(new ComoportementEpee());
		p.comportementarme.UtiliserArme();
		
		
	}
	private static ComportementArme selectArme(){
		Scanner cl = new Scanner(System.in);
		
		while (true) {
			System.out.println("selectionner arme");
			
			String arme = cl.nextLine();
			arme = arme.toLowerCase();
			
			switch (arme) {
			case "poignard":
				return new ComportementPoignard();
			case "arc":
				return new ComoportementArc();
			case "epee":
				return new ComoportementEpee();
	
			default:
				
				break;
			}
		}
	}

}
