
public class CanardMuet implements ComportementCancan{

	@Override
	public void cancaner() {
		// TODO Auto-generated method stub
		
	}

}
