
public class Coincoin implements ComportementCancan {

	public void cancaner() {
		System.out.println("CoinCoin!");
	}
}
