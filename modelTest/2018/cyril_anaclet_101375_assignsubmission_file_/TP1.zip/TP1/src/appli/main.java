package appli;

import comportementArme.impl.ComportementArc;
import comportementArme.impl.ComportementPoignard;

public class main {

	public static void main(String[] args) {
		Reine r = new Reine(new ComportementArc());
		r.combattre();
		r.setArme(new ComportementPoignard());
		r.combattre();

	}

}
