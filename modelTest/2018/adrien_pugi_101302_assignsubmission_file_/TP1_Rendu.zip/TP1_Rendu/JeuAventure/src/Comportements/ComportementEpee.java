package Comportements;

public class ComportementEpee implements ComportementArme {

	@Override
	public void utiliserArme() {
		System.out.println("Je combat avec une Epee!");
	}

}
