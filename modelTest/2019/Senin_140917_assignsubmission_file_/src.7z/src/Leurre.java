public class Leurre {

}
