import Comportements.ComportementArme;

public class Troll extends Personnage {

	public Troll(ComportementArme a) {
		super(a);
		// TODO Auto-generated constructor stub
	}
	
	public void afficher() {
		System.out.println("Je suis un Troll");
	}
	

}
