package adventureGame;

import adventureGame.comportement.ComportementArme;

public class Reine extends Personnage {

	public Reine(ComportementArme c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void combattre() {
		super.combattre();
	}

	
}